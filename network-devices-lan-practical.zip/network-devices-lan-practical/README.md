# Network Devices and LAN Configuration

A Computer Networks laboratory practical covering common network devices and the setup and verification of a small Local Area Network (LAN).

## Aim
To study network devices and connect computers in a LAN using an Ethernet switch, Ethernet cables, IPv4 configuration, and `ping` connectivity tests.

## Network devices studied
- **NIC (Network Interface Card):** Provides a computer with a network connection.
- **Repeater:** Regenerates/retimes signals to extend a network link; OSI Layer 1.
- **Hub:** Repeats incoming signals to the other ports; OSI Layer 1.
- **Switch:** Learns MAC addresses and forwards Ethernet frames to the appropriate port; typically OSI Layer 2.
- **Bridge:** Connects and filters traffic between LAN segments using MAC addresses; OSI Layer 2.
- **Router:** Forwards IP packets between different IP networks; OSI Layer 3.
- **Gateway:** Connects systems or networks; may perform protocol translation. A default gateway in a typical LAN is usually a router.

## Example LAN topology

See [`network-diagram.svg`](network-diagram.svg).

Three computers connect to separate ports on one Ethernet switch.

## Example IPv4 plan

For an isolated LAN, computers can communicate within the same subnet without a default gateway.

| Device | IPv4 address | Subnet mask | Default gateway |
|---|---|---|---|
| PC1 | `192.168.1.10` | `255.255.255.0` | Leave blank for isolated LAN |
| PC2 | `192.168.1.11` | `255.255.255.0` | Leave blank for isolated LAN |
| PC3 | `192.168.1.12` | `255.255.255.0` | Leave blank for isolated LAN |

If a router is connected, use the router's actual LAN address as the default gateway. Do not configure a gateway address that does not exist on the network.

## Procedure

1. Connect each computer's Ethernet NIC to a separate switch port using a working Ethernet cable.
2. Power on the computers and switch; check link/activity indicators.
3. Configure unique IPv4 addresses in the same subnet, using the table above as an example.
4. On Windows, open **Control Panel → Network and Sharing Center → Change adapter settings**. Open **Ethernet → Properties → Internet Protocol Version 4 (TCP/IPv4) → Properties** to configure a static address.
5. On each Windows computer, open Command Prompt and run `ipconfig` to verify the configuration.
6. From PC1, run `ping 192.168.1.11` and `ping 192.168.1.12`.
7. From PC2, run `ping 192.168.1.10`.
8. Save screenshots of your **actual** configuration and test results in the `outputs/` folder.

## Useful commands

```bat
ipconfig
ping 192.168.1.11
ping 192.168.1.12
```

On Linux, use `ip addr` to inspect interface addresses and the same `ping` command to test connectivity.

## Troubleshooting

- Check that cables are firmly connected and link lights are active.
- Ensure each computer has a unique IP address and the same subnet mask.
- Check that the Ethernet adapter is enabled.
- A host firewall may block incoming ICMP echo requests; check permitted firewall rules if ping fails.
- For an isolated LAN, a default gateway is not needed for communication within the same subnet.
- A successful ping confirms IP connectivity between the endpoints at the time of testing; it does not by itself prove Internet access.

## Results

Fill in the results below after performing the practical:

- PC1 to PC2: **[Record actual result]**
- PC1 to PC3: **[Record actual result]**
- PC2 to PC1: **[Record actual result]**

Do not claim success until the tests have actually been run.

## Repository contents

- `README.md` — project overview and quick instructions.
- `docs/experiment.md` — detailed practical record.
- `network-diagram.svg` — LAN topology diagram.
- `outputs/README.md` — instructions for adding genuine screenshots.

## Evidence

Place genuine screenshots captured during your own practical execution in `outputs/`. Suggested filenames:
- `ipconfig-pc1.png`
- `ping-pc1-to-pc2.png`
- `ping-pc1-to-pc3.png`

These are suggested filenames only; add screenshots only after capturing them.
